# Simple-Auth-PHP
Just a simple signup,loginauth with HTML,bootstrap,PHP
